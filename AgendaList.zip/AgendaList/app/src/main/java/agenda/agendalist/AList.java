package agenda.agendalist;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;

public class AList extends Activity {

    Button siguiente;
    Button siguiente2;
    Button siguiente3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prueba);
        /*
        String [] asunto={"Desayuno", "Conferencia 1", "Conferencia 2"};
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(getListView().getContext(),android.R.layout.simple_list_item_1,asunto);
        getListView().setAdapter(adapter);
        */

        //Obtiene el elemento del boton
        siguiente=(Button)findViewById(R.id.btn1);
        //Asigna un listener al boton
        siguiente.setOnClickListener (new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //Acciones cuando se haga clic
                //Se crea un intent con (VistaOrigen, VistaDestino)
                Intent siguiente=new Intent(AList.this,AList2.class);
                //Se manda llamar la siguiente actividad
                startActivity(siguiente);


            }
        });

        siguiente2=(Button)findViewById(R.id.btn2);
        siguiente2.setOnClickListener (new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent siguiente2=new Intent(AList.this,Alist3.class);

                startActivity(siguiente2);


            }
        });

        siguiente3=(Button)findViewById(R.id.btn3);
        siguiente3.setOnClickListener (new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent siguiente3=new Intent(AList.this,Alist4.class);

                startActivity(siguiente3);


            }
        });


    }
}
